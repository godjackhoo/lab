/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package library;
import java.sql.*;
/**
 *
 * @author leader
 */
public class DatabaseConnection {
    public static void main(String[] args){
        new DatabaseConnection();
    }
    public DatabaseConnection(){
    Connection conn=null;
    try{
    String url="jdbc:mysql://localhost:3306/library";
    String user="root";
    String password="";
    
    conn=DriverManager.getConnection(url,user,password);
    System.out.println("connection successful");
    }catch(SQLException ex){
        
    }
    }
}
