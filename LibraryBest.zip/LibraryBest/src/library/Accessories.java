/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package library;
import java.text.DateFormat;
import java.util.Calendar;
import java.text.SimpleDateFormat;
import java.util.Date;
/**
 *
 * @author leader
 */
public class Accessories {
    public static void main(String[]args){
      DateFormat dateFormat=new SimpleDateFormat("yyy/MM/ HH:mm:ss");
      Date date=new Date();
      //System.out.println()
      /*Calendar cal=Calendar.getInstance();
      SimpleDateFormat sdf=new SimpleDateFormat("HH:mm:ss");
      System.out.println(dateFormat.format(cal.getTime));
     */
        System.out.println(dateFormat.format(date));
      
    }
}
